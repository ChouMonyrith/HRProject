
#pragma once
#include<iostream>
using namespace std;

class Employee {
private:
	string name;
	int id;
	double salary;
	double workhour;
	double costhour;
public:
	Employee() {
		name = "";
		id = 0;
		salary = 0;
		workhour = 0;
		costhour = 0;
	}
	Employee(string name, int id, double salary, double workhour, double costhour) {
		this->name = name;
		this->id = id;
		this->salary = salary;
		this->workhour = workhour;
		this->costhour = costhour;
	}
	Employee(string name, int id) {
		this->name = name;
		this->id = id;
	}
	~Employee() {

	}
	void set_name(string name) {
		this->name = name;
	}
	void set_id(int id) {
		this->id = id;
	}
	void set_salary(double salary) {
		this->salary = salary;
	}
	void set_workhour(double salary) {
		this->workhour = workhour;
	}
	void set_costhour(double costhour) {
		this->costhour = costhour;
	}
	string get_name() {
		return this->name;
	}
	int get_id() {
		return this->id;
	}
	double get_salary() {
		return this->salary;
	}
	double get_workhour() {
		return this->workhour;
	}
	double get_costhour() {
		return this->costhour;
	}

	void get_data()
	{
		cout << "Enter Employee Name: ";
		cin >> name;
		cout << "Enter Employee ID: ";
		cin >> id;
		cout << "Enter Work Hour: ";
		cin >> workhour;
		cout << "Enter Cost Per Hour: ";
		cin >> costhour;

	}
	double getPay() {
		return workhour * costhour;
	}
	void show_data() {
		int option;
		if (option==1)
		{
			cout << "--------------------------" << endl;
			cout << "	  Employee Details" << endl;
			cout << "Employee Name: " << name << endl;
			cout << "Employee ID: " << id << endl;
			cout << "Work Hour: " << workhour << endl;
			cout << "Cost Per Hour: " << costhour << endl;
			cout << "Salary: " << getPay() << endl;
			cout << "Full Time Employee" << endl;
			cout << "--------------------------" << endl;
		}
		else if (option == 2) {
			cout << "--------------------------" << endl;
			cout << "	Employee Details" << endl;
			cout << "Employee Name: " << name << endl;
			cout << "Employee ID: " << id << endl;
			cout << "Work Hour: " << workhour << endl;
			cout << "Cost Per Hour: " << costhour << endl;
			cout << "Salary: " << getPay() << endl;
			cout << "Part Time Employee" << endl;
			cout << "--------------------------" << endl;
		}
	}

};