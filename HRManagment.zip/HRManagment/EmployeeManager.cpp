#pragma once
#include <iostream>
#include "Employee.cpp"
#include "DynamicArray.cpp"
#include <vector>
#include <fstream>
#include <string>

using namespace std;

//business logics
class EmployeeManager {
private:
    //dynamic array
vector<Employee*>employees;
public:

    EmployeeManager() {
        //loadEmployeeFromFile();
    }
    ~EmployeeManager() {
        vector<Employee*>::iterator it;
        for (it = employees.begin(); it != employees.end(); it++) {
            delete* it;
        }
    }

    void addEmployee(Employee& employee) {
        employees.push_back(&employee);
		cout << "Added successfully" << endl; 
    }

    void viewEmployee() {
        vector<Employee*>::iterator it;
        for (it = employees.begin(); it != employees.end(); it++) {
            cout << "Employee Details: " << endl;
            (*it)->show_data();
            cout << endl;
        }
    }

    void updateEmployee(string name) {
        int switch_on = 0;
		bool found = false;
        string newName;
        vector<Employee*>::iterator it;
            cout << "What do you want to edit?" << endl;
            cout << "1.Edit Name" << endl;
            cout << "2.Edit Cost Per Hour" << endl;
            cout << "3.Edit Work Hour" << endl;
            switch (switch_on)
            case 1: {
                for (it = employees.begin(); it != employees.end(); it++) {
                    if ((*it)->get_name() == name) {
                        cout << "Enter new name: ";
                        string newName;
                        cin >> newName;
                        (*it)->set_name(newName);
						found = true;
                    }
                }	break;
            case 2: {
                for (it = employees.begin(); it != employees.end(); it++) {
                    if ((*it)->get_name() == name) {
                        cout << "Enter new cost per hour: ";
                        double newCost;
                        cin >> newCost;
                        (*it)->set_costhour(newCost);
						found = true;
                    }
                    break;
                }
            case 3: {
                for (it = employees.begin(); it != employees.end(); it++) {
                    if ((*it)->get_name() == name) {

                        cout << "Enter new work hour: ";
                        double newWork;
                        cin >> newWork;
                        (*it)->set_workhour(newWork);
						found = true;
                    }
                    break;
                }
            }
              defualt: cout << "Invalid input" << endl;
                  break;
                }
            }  
  
    }
    void searchEmployee(string name) {
        vector<Employee*>::iterator it;
        for (it = employees.begin(); it != employees.end(); it++) {
            if ((*it)->get_name().compare(name) == 0) {
                (*it)->show_data();
                break;
            }
        }
    }

    void deleteEmployee(string name) {
        char confirm;
        vector<Employee*>::iterator it;
        for (it = employees.begin(); it != employees.end(); it++) {
            if ((*it)->get_name().compare(name) == 0) {
				cout << "Are you sure you want to delete this employee? (y/n)";
				cin >> confirm;
				if (confirm == 'y'||confirm=='Y') {
                employees.erase(it);
				cout << "Deleted successfully" << endl;
                }
                else
                {
					cout << "Employee not deleted" << endl;
                }
                break;
            }
        }
    }

    Employee* getEmployeeByName(string name) {
        vector<Employee*>::iterator it;
        for (it = employees.begin(); it != employees.end(); it++) {
            if ((*it)->get_name().compare(name) == 0) {
                return *it;
            }
        }
        return nullptr;
    }

    vector<Employee*> getAllEmployees() {
        return employees;
    }



    //Read and write object data into file
    void saveEmployee() {
        ofstream outputFile;
        outputFile.open("employees.bin", ios::out | ios::binary | ios::trunc);
        if (!outputFile) {
            cout << "Error in creating file...\n";
            exit(1);
        }
        else {
            vector<Employee*>::iterator it;
            for (it = employees.begin(); it != employees.end(); it++) {
                outputFile.write((char*)&it, sizeof(it));
                (*it)->show_data();
				cout << "Saved successfully" << endl;
            }
        }

        outputFile.close();
    }
    void loadEmployeeFromFile() {
        Employee employee;
        ifstream inputFile;
        inputFile.open("employees.bin", ios::in | ios::binary);
        if (!inputFile) {
            cout << "Error in opening file...\n";
            exit(1);
        }
        else {
            while (inputFile.read((char*)(&employee), sizeof(employee))) {
                employees.push_back(&employee);
                employee.show_data();
                cout << "H1" << endl;
            }
        }


        cout << "H2" << endl;
        inputFile.close();
    }


};