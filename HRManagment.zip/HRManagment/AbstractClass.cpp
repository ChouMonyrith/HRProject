#pragma once
#include<iostream>

using namespace std;

class Abstract {
public: 
	virtual void Employee() = 0;
};