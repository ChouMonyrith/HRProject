#pragma once
#include<iostream>
#include"Application.cpp"
#include"Login.cpp"
using namespace std;


int main() {

    Login login;
    while (true)
    {
        string username, password;
        int ch;
        int role;
        cout << " ********  Welcome to Human Resource Management System *********";
        cout << "\n 1. Login \n 2. Register \n 3. Exit" << endl;
        cout << "Enter choice: ";
        cin >> ch;
        switch (ch)
        {
        case 1:
            if(login.userLogin()==true){
				Application app;
				app.run();
            break;
        case 2:
            login.userRegister();
            break;
        case 3:
            exit(1);
        }
        default:
			cout << "Invalid choice" << endl;
			break;
		}

    }

    return 0;
}