#pragma once
#include<iostream>
#include"Employee.cpp"
#include"EmployeeManager.cpp"
using namespace std;

class PartTimeEmployee : public Employee {
private:
	double costhour = 0;
	double workhour = 0;

public:
	PartTimeEmployee() :Employee() {
		costhour = 0;
		workhour = 0;
	

	}
	PartTimeEmployee(int id, string name, double costhour, double workhour) : Employee(name, id) {
		this->costhour = costhour;
		this->workhour = workhour;
	
	}

	double getPay() {
		return costhour * workhour;
	}
	void show_data() {
		Employee::show_data();
		cout << "Cost Hour: " << costhour << endl;
		cout << "Work Hour: " << workhour << endl;
	}
	void get_data() {
		Employee::get_data();
		cout << "------------------------" << endl;
		cout << "PartTime Employee" << endl;
		cout << "Enter Cost Hour: ";
		cin >> costhour;
		cout << "Enter Work Hour: ";
		cin >> workhour;
		cout << endl;
		cout << "------------------------" << endl;
	}


};