#pragma once
#include<iostream>
#include"Employee.cpp"
#include"User.cpp"
#include"EmployeeManager.cpp"
#include"PartTimeEmployee.cpp"
#include"FullTimeEmployee.cpp"
using namespace std;

class Application {
public:
	void run() {
		int option;
		int count = 0;
		string name;
		FullTimeEmployee fte;
		PartTimeEmployee pte;
		EmployeeManager em;

		do {
			showMenu();
			int choice = getChoice();
			switch (choice) {
			case 1:
			{
				cout << "Employee Type" << endl;
				cout << "1. Full Time Employee" << endl;
				cout << "2. Part Time Employee" << endl;
				cout << "Enter your choice: ";
				cin >> option;
				switch (option) {
				case 1: {
					FullTimeEmployee* fte = new FullTimeEmployee();
					fte->get_data();
					em.addEmployee(*fte);
					break;
				}

				case 2:
				{
					PartTimeEmployee* pte = new PartTimeEmployee();
					pte->get_data();
					em.addEmployee(*pte);
					count++;
					break;
				}
				default:
					break;
				}
			}
			
			case 2: {
				em.viewEmployee();
				break;
			}
			case 3: {
				cout << "Enter employee name: ";
				cin >> name;
				em.searchEmployee(name);
				break;
			}
			case 4: {
				cout << "Enter Name: ";
				cin >> name;
				em.updateEmployee(name);
				break;
			}
			case 5: {
				cout << "Enter employee name: ";
				cin >> name;
				em.deleteEmployee(name);
				break;
			}
			case 6: {
				em.saveEmployee();
				break;
			}
			case 7: {
				em.loadEmployeeFromFile();
				cout << "Employees loaded successfully." << endl;
				break;
			}
			case 0: {
				exit(0);
				break;
			}
			default:
				break;
			}
		}
	 while (true);
}


	void showMenu() {
		cout << "**********MENU**********" << endl;
		cout << "1. Add Employee" << endl;
		cout << "2. Show Employee" << endl;
		cout << "3. Search Employee" << endl;
		cout << "4. Update Employee" << endl;
		cout << "5. Delete Employee" << endl;
		cout << "6. Save" << endl;
		cout << "7. Load" << endl;
		cout << "8. Exit" << endl;
	}

	int getChoice() {
		int choice;
		cout << "Enter your choice: ";
		cin >> choice;
		while (choice < 1 || choice > 7) {
			cout << "Invalid Choice. Please try again: ";
			showMenu();
			cin >> choice;
		}
		return choice;
	}
};
